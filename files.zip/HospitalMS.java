import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Hospital Management System
 * Author: Your Name | Chandigarh University
 * Run: javac HospitalMS.java && java HospitalMS
 */
public class HospitalMS {

    // ─── THEME ────────────────────────────────────────────────────────────────
    static final Color PRIMARY    = new Color(26,  100, 150);
    static final Color PRIMARY_DK = new Color(18,   70, 110);
    static final Color ACCENT     = new Color(22,  160, 133);
    static final Color DANGER     = new Color(192,  57,  43);
    static final Color SUCCESS    = new Color(39,  174,  96);
    static final Color WARNING    = new Color(243, 156,  18);
    static final Color BG         = new Color(245, 247, 250);
    static final Color CARD_BG    = Color.WHITE;
    static final Color TEXT_DARK  = new Color(30,  30,  40);
    static final Color TEXT_MID   = new Color(100, 110, 130);
    static final Color BORDER_CLR = new Color(220, 225, 235);
    static final Font  TITLE_FONT = new Font("Segoe UI", Font.BOLD, 20);
    static final Font  BODY_FONT  = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font  BOLD_FONT  = new Font("Segoe UI", Font.BOLD, 13);
    static final Font  SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 11);

    // ─── IN-MEMORY DATABASE ───────────────────────────────────────────────────
    static final List<String[]> PATIENTS     = new ArrayList<>();
    static final List<String[]> DOCTORS      = new ArrayList<>();
    static final List<String[]> APPOINTMENTS = new ArrayList<>();
    static final List<String[]> BILLS        = new ArrayList<>();
    static final List<String[]> MEDICINES    = new ArrayList<>();
    static int patId = 1001, docId = 201, apptId = 3001, billId = 5001, medId = 7001;

    static {
        // Seed patients  [id, name, age, gender, contact, blood, address, disease]
        PATIENTS.add(new String[]{"P1001","Arjun Sharma","34","Male","9876543210","A+","Delhi","Hypertension"});
        PATIENTS.add(new String[]{"P1002","Priya Verma","28","Female","9123456789","B+","Mumbai","Diabetes"});
        PATIENTS.add(new String[]{"P1003","Ravi Kumar","52","Male","9012345678","O-","Chandigarh","Cardiac Issue"});
        PATIENTS.add(new String[]{"P1004","Sunita Devi","41","Female","8901234567","AB+","Ludhiana","Asthma"});

        // Seed doctors  [id, name, specialization, contact, schedule, fee]
        DOCTORS.add(new String[]{"D201","Dr. Amit Joshi","Cardiologist","9765432100","Mon-Fri 09:00-14:00","800"});
        DOCTORS.add(new String[]{"D202","Dr. Neha Singh","Dermatologist","9654321009","Tue-Sat 10:00-16:00","600"});
        DOCTORS.add(new String[]{"D203","Dr. Rahul Gupta","Neurologist","9543210098","Mon-Wed-Fri 11:00-15:00","900"});
        DOCTORS.add(new String[]{"D204","Dr. Kavya Rao","Pediatrician","9432100987","Mon-Sat 08:00-13:00","500"});

        // Seed appointments  [id, patId, patName, docName, date, time, status]
        APPOINTMENTS.add(new String[]{"A3001","P1001","Arjun Sharma","Dr. Amit Joshi","2025-09-10","10:00","Completed"});
        APPOINTMENTS.add(new String[]{"A3002","P1002","Priya Verma","Dr. Kavya Rao","2025-09-11","11:30","Scheduled"});
        APPOINTMENTS.add(new String[]{"A3003","P1003","Ravi Kumar","Dr. Rahul Gupta","2025-09-12","14:00","Scheduled"});

        // Seed bills  [id, patName, apptId, amount, mode, status, date]
        BILLS.add(new String[]{"B5001","Arjun Sharma","A3001","1350","Cash","Paid","2025-09-10"});
        BILLS.add(new String[]{"B5002","Priya Verma","A3002","950","UPI","Pending","2025-09-11"});

        // Seed medicines  [id, name, category, qty, price, expiry]
        MEDICINES.add(new String[]{"M7001","Paracetamol 500mg","Analgesic","200","5","2026-12-31"});
        MEDICINES.add(new String[]{"M7002","Amoxicillin 250mg","Antibiotic","150","18","2026-06-30"});
        MEDICINES.add(new String[]{"M7003","Metformin 500mg","Anti-diabetic","80","12","2026-09-30"});
        MEDICINES.add(new String[]{"M7004","Aspirin 75mg","Antiplatelet","15","8","2026-11-30"});  // low stock
        MEDICINES.add(new String[]{"M7005","Atorvastatin 10mg","Statin","90","25","2026-08-31"});
    }

    // ─── ENTRY POINT ──────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(LoginFrame::new);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  UI UTILITIES
    // ═════════════════════════════════════════════════════════════════════════

    static JButton primaryBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(PRIMARY); b.setForeground(Color.WHITE);
        b.setFont(BOLD_FONT); b.setFocusPainted(false);
        b.setBorderPainted(false); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){ b.setBackground(PRIMARY_DK); }
            public void mouseExited(MouseEvent e){ b.setBackground(PRIMARY); }
        });
        return b;
    }

    static JButton dangerBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(DANGER); b.setForeground(Color.WHITE);
        b.setFont(BOLD_FONT); b.setFocusPainted(false);
        b.setBorderPainted(false); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        return b;
    }

    static JButton successBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(SUCCESS); b.setForeground(Color.WHITE);
        b.setFont(BOLD_FONT); b.setFocusPainted(false);
        b.setBorderPainted(false); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        return b;
    }

    static JTextField styledField(String placeholder) {
        JTextField f = new JTextField(15);
        f.setFont(BODY_FONT); f.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_CLR, 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        f.setForeground(TEXT_MID);
        f.setText(placeholder);
        f.addFocusListener(new FocusAdapter(){
            public void focusGained(FocusEvent e){ if(f.getText().equals(placeholder)){ f.setText(""); f.setForeground(TEXT_DARK); } }
            public void focusLost(FocusEvent e){ if(f.getText().isEmpty()){ f.setText(placeholder); f.setForeground(TEXT_MID); } }
        });
        return f;
    }

    static JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(TITLE_FONT); l.setForeground(TEXT_DARK);
        l.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        return l;
    }

    static JPanel card(String title) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(CARD_BG);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_CLR, 1, true),
            BorderFactory.createEmptyBorder(16, 20, 16, 20)));
        if (title != null) {
            JLabel lbl = new JLabel(title);
            lbl.setFont(BOLD_FONT); lbl.setForeground(PRIMARY);
            lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
            p.add(lbl, BorderLayout.NORTH);
        }
        return p;
    }

    static JTable styledTable(String[] cols, DefaultTableModel model) {
        JTable t = new JTable(model) {
            public boolean isCellEditable(int r, int c){ return false; }
        };
        t.setFont(BODY_FONT); t.setRowHeight(32);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(new Color(220, 235, 250));
        t.setSelectionForeground(TEXT_DARK);
        t.setBackground(CARD_BG);
        JTableHeader h = t.getTableHeader();
        h.setFont(BOLD_FONT); h.setBackground(PRIMARY); h.setForeground(Color.WHITE);
        h.setPreferredSize(new Dimension(0, 38));
        h.setBorder(BorderFactory.createEmptyBorder());
        DefaultTableCellRenderer r2 = new DefaultTableCellRenderer(){
            int row = 0;
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean sel, boolean foc, int row, int col){
                Component c = super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                if(!sel) c.setBackground(row % 2 == 0 ? CARD_BG : new Color(248,250,254));
                setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
                return c;
            }
        };
        r2.setHorizontalAlignment(SwingConstants.LEFT);
        for(int i=0;i<t.getColumnCount();i++) t.getColumnModel().getColumn(i).setCellRenderer(r2);
        return t;
    }

    static JComboBox<String> styledCombo(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(BODY_FONT); cb.setBackground(CARD_BG);
        cb.setBorder(new LineBorder(BORDER_CLR, 1, true));
        return cb;
    }

    static void showMsg(Component parent, String msg, String title, int type) {
        JOptionPane.showMessageDialog(parent, msg, title, type);
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  LOGIN FRAME
    // ═════════════════════════════════════════════════════════════════════════
    static class LoginFrame extends JFrame {
        LoginFrame() {
            setTitle("Hospital Management System – Login");
            setSize(900, 560); setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setLayout(new BorderLayout());
            setResizable(false);

            // Left panel
            JPanel left = new JPanel(new GridBagLayout());
            left.setBackground(PRIMARY);
            left.setPreferredSize(new Dimension(380, 560));
            JPanel leftInner = new JPanel();
            leftInner.setLayout(new BoxLayout(leftInner, BoxLayout.Y_AXIS));
            leftInner.setOpaque(false);

            JLabel logo = new JLabel("🏥");
            logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
            logo.setAlignmentX(CENTER_ALIGNMENT);

            JLabel title = new JLabel("HMS");
            title.setFont(new Font("Segoe UI", Font.BOLD, 48));
            title.setForeground(Color.WHITE); title.setAlignmentX(CENTER_ALIGNMENT);

            JLabel sub = new JLabel("Hospital Management System");
            sub.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            sub.setForeground(new Color(180,210,230)); sub.setAlignmentX(CENTER_ALIGNMENT);

            JLabel sub2 = new JLabel("Chandigarh University");
            sub2.setFont(SMALL_FONT); sub2.setForeground(new Color(140,180,210));
            sub2.setAlignmentX(CENTER_ALIGNMENT);

            leftInner.add(logo); leftInner.add(Box.createVerticalStrut(8));
            leftInner.add(title); leftInner.add(Box.createVerticalStrut(8));
            leftInner.add(sub);  leftInner.add(Box.createVerticalStrut(4));
            leftInner.add(sub2);
            left.add(leftInner);

            // Right panel – login form
            JPanel right = new JPanel(new GridBagLayout());
            right.setBackground(BG);
            JPanel form = new JPanel();
            form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
            form.setOpaque(false); form.setMaximumSize(new Dimension(320, 400));

            JLabel loginTitle = new JLabel("Welcome Back");
            loginTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
            loginTitle.setForeground(TEXT_DARK); loginTitle.setAlignmentX(CENTER_ALIGNMENT);

            JLabel hint = new JLabel("Sign in to your account");
            hint.setFont(BODY_FONT); hint.setForeground(TEXT_MID);
            hint.setAlignmentX(CENTER_ALIGNMENT);

            JTextField userField = new JTextField("admin"); userField.setFont(BODY_FONT);
            userField.setMaximumSize(new Dimension(320, 42));
            userField.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_CLR,1,true), BorderFactory.createEmptyBorder(8,12,8,12)));

            JPasswordField passField = new JPasswordField("admin"); passField.setFont(BODY_FONT);
            passField.setMaximumSize(new Dimension(320, 42));
            passField.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_CLR,1,true), BorderFactory.createEmptyBorder(8,12,8,12)));

            JComboBox<String> roleBox = styledCombo(new String[]{"Admin","Doctor","Receptionist"});
            roleBox.setMaximumSize(new Dimension(320, 42));

            JButton loginBtn = new JButton("Sign In");
            loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
            loginBtn.setBackground(PRIMARY); loginBtn.setForeground(Color.WHITE);
            loginBtn.setFocusPainted(false); loginBtn.setBorderPainted(false);
            loginBtn.setMaximumSize(new Dimension(320, 46));
            loginBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            loginBtn.addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){ loginBtn.setBackground(PRIMARY_DK); }
                public void mouseExited(MouseEvent e){ loginBtn.setBackground(PRIMARY); }
            });

            JLabel info = new JLabel("Default: admin / admin");
            info.setFont(SMALL_FONT); info.setForeground(TEXT_MID);
            info.setAlignmentX(CENTER_ALIGNMENT);

            loginBtn.addActionListener(e -> {
                if(userField.getText().isBlank() || new String(passField.getPassword()).isBlank()){
                    showMsg(this,"Please enter credentials.","Error",JOptionPane.ERROR_MESSAGE); return;
                }
                dispose();
                new MainFrame((String)roleBox.getSelectedItem(), userField.getText());
            });
            passField.addActionListener(e -> loginBtn.doClick());

            form.add(loginTitle); form.add(Box.createVerticalStrut(4));
            form.add(hint);       form.add(Box.createVerticalStrut(28));
            form.add(mkLabel("Username")); form.add(Box.createVerticalStrut(4));
            form.add(userField);  form.add(Box.createVerticalStrut(14));
            form.add(mkLabel("Password")); form.add(Box.createVerticalStrut(4));
            form.add(passField);  form.add(Box.createVerticalStrut(14));
            form.add(mkLabel("Role"));     form.add(Box.createVerticalStrut(4));
            form.add(roleBox);    form.add(Box.createVerticalStrut(22));
            form.add(loginBtn);   form.add(Box.createVerticalStrut(10));
            form.add(info);

            right.add(form);
            add(left, BorderLayout.WEST);
            add(right, BorderLayout.CENTER);
            setVisible(true);
        }
        JLabel mkLabel(String t){ JLabel l=new JLabel(t); l.setFont(BOLD_FONT); l.setForeground(TEXT_DARK); return l; }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  MAIN FRAME (DASHBOARD + TABS)
    // ═════════════════════════════════════════════════════════════════════════
    static class MainFrame extends JFrame {
        String role, user;
        JPanel contentArea;
        JLabel pageTitle, statusBar;
        Map<String,JButton> navBtns = new LinkedHashMap<>();

        MainFrame(String role, String user) {
            this.role = role; this.user = user;
            setTitle("Hospital Management System");
            setSize(1200, 720); setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setLayout(new BorderLayout());

            // ─ Sidebar
            JPanel sidebar = new JPanel();
            sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
            sidebar.setBackground(PRIMARY_DK);
            sidebar.setPreferredSize(new Dimension(210, 0));

            JPanel sHead = new JPanel(new BorderLayout());
            sHead.setBackground(new Color(12,50,80));
            sHead.setBorder(BorderFactory.createEmptyBorder(16,16,16,16));
            JLabel appName = new JLabel("<html><b>HMS</b> Portal</html>");
            appName.setFont(new Font("Segoe UI",Font.BOLD,17));
            appName.setForeground(Color.WHITE);
            sHead.add(appName, BorderLayout.CENTER);
            sidebar.add(sHead);

            String[][] menus = {
                {"🏠","Dashboard"},{"👤","Patients"},{"🩺","Doctors"},
                {"📅","Appointments"},{"💳","Billing"},{"💊","Pharmacy"}
            };

            for(String[] m : menus){
                JButton btn = sidebarBtn(m[0]+" "+m[1]);
                navBtns.put(m[1], btn);
                btn.addActionListener(e -> {
                    navBtns.values().forEach(b -> b.setBackground(PRIMARY_DK));
                    btn.setBackground(PRIMARY);
                    showPage(m[1]);
                });
                sidebar.add(btn);
            }
            sidebar.add(Box.createVerticalGlue());

            // user info
            JPanel userInfo = new JPanel(new BorderLayout());
            userInfo.setBackground(new Color(12,50,80));
            userInfo.setBorder(BorderFactory.createEmptyBorder(12,14,12,14));
            JLabel uLabel = new JLabel("<html><b>"+user+"</b><br><font color='#88bbdd'>"+role+"</font></html>");
            uLabel.setFont(new Font("Segoe UI",Font.PLAIN,12));
            uLabel.setForeground(Color.WHITE);
            JButton logoutBtn = new JButton("⏻");
            logoutBtn.setFont(new Font("Segoe UI",Font.BOLD,16));
            logoutBtn.setBackground(DANGER); logoutBtn.setForeground(Color.WHITE);
            logoutBtn.setBorderPainted(false); logoutBtn.setFocusPainted(false);
            logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            logoutBtn.setPreferredSize(new Dimension(36,36));
            logoutBtn.addActionListener(e -> { dispose(); new LoginFrame(); });
            userInfo.add(uLabel, BorderLayout.CENTER);
            userInfo.add(logoutBtn, BorderLayout.EAST);
            sidebar.add(userInfo);

            // ─ Top bar
            JPanel topBar = new JPanel(new BorderLayout());
            topBar.setBackground(CARD_BG);
            topBar.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0,0,1,0,BORDER_CLR),
                BorderFactory.createEmptyBorder(10,24,10,24)));
            pageTitle = new JLabel("Dashboard");
            pageTitle.setFont(new Font("Segoe UI",Font.BOLD,18));
            pageTitle.setForeground(TEXT_DARK);
            JLabel dateLabel = new JLabel(new SimpleDateFormat("EEE, dd MMM yyyy").format(new Date()));
            dateLabel.setFont(BODY_FONT); dateLabel.setForeground(TEXT_MID);
            topBar.add(pageTitle, BorderLayout.WEST);
            topBar.add(dateLabel, BorderLayout.EAST);

            // ─ Content area
            contentArea = new JPanel(new CardLayout());
            contentArea.setBackground(BG);

            // ─ Status bar
            statusBar = new JLabel("  Ready");
            statusBar.setFont(SMALL_FONT); statusBar.setForeground(TEXT_MID);
            statusBar.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(1,0,0,0,BORDER_CLR),
                BorderFactory.createEmptyBorder(4,14,4,14)));
            statusBar.setBackground(CARD_BG); statusBar.setOpaque(true);

            add(sidebar, BorderLayout.WEST);
            add(topBar, BorderLayout.NORTH);
            add(contentArea, BorderLayout.CENTER);
            add(statusBar, BorderLayout.SOUTH);

            // Build pages
            contentArea.add(new DashboardPanel(), "Dashboard");
            contentArea.add(new PatientPanel(this), "Patients");
            contentArea.add(new DoctorPanel(this), "Doctors");
            contentArea.add(new AppointmentPanel(this), "Appointments");
            contentArea.add(new BillingPanel(this), "Billing");
            contentArea.add(new PharmacyPanel(this), "Pharmacy");

            navBtns.get("Dashboard").setBackground(PRIMARY);
            setVisible(true);
        }

        void showPage(String name) {
            pageTitle.setText(name);
            CardLayout cl = (CardLayout) contentArea.getLayout();
            cl.show(contentArea, name);
            setStatus("Viewing: " + name);
        }

        void setStatus(String msg) {
            statusBar.setText("  " + msg + "  |  " + new SimpleDateFormat("HH:mm:ss").format(new Date()));
        }

        JButton sidebarBtn(String text) {
            JButton b = new JButton(text);
            b.setFont(new Font("Segoe UI",Font.PLAIN,14));
            b.setForeground(Color.WHITE); b.setBackground(PRIMARY_DK);
            b.setBorderPainted(false); b.setFocusPainted(false);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setBorder(BorderFactory.createEmptyBorder(12,18,12,18));
            b.setMaximumSize(new Dimension(210,48));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addMouseListener(new MouseAdapter(){
                public void mouseEntered(MouseEvent e){ if(!b.getBackground().equals(PRIMARY)) b.setBackground(new Color(22,80,120)); }
                public void mouseExited(MouseEvent e){ if(!b.getBackground().equals(PRIMARY)) b.setBackground(PRIMARY_DK); }
            });
            return b;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  DASHBOARD PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class DashboardPanel extends JPanel {
        DashboardPanel() {
            setLayout(new BorderLayout(16,16));
            setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            // Stats row
            JPanel statsRow = new JPanel(new GridLayout(1,4,16,0));
            statsRow.setOpaque(false);
            statsRow.add(statCard("Total Patients", String.valueOf(PATIENTS.size()), "👤", new Color(41,128,185)));
            statsRow.add(statCard("Total Doctors",  String.valueOf(DOCTORS.size()),  "🩺", new Color(39,174,96)));
            statsRow.add(statCard("Appointments",   String.valueOf(APPOINTMENTS.size()), "📅", new Color(142,68,173)));
            long pending = BILLS.stream().filter(b->b[5].equals("Pending")).count();
            statsRow.add(statCard("Pending Bills",  String.valueOf(pending), "💳", new Color(192,57,43)));

            // Recent appointments table
            JPanel apptCard = card("Recent Appointments");
            String[] cols = {"Appt ID","Patient","Doctor","Date","Time","Status"};
            DefaultTableModel m = new DefaultTableModel(cols,0);
            for(String[] a : APPOINTMENTS) m.addRow(new Object[]{a[0],a[2],a[3],a[4],a[5],a[6]});
            JTable t = styledTable(cols,m);
            // Color status column
            t.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer(){
                public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                    JLabel l=(JLabel)super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                    l.setFont(BOLD_FONT); l.setHorizontalAlignment(CENTER);
                    String v=val.toString();
                    if(v.equals("Completed")) l.setForeground(SUCCESS);
                    else if(v.equals("Scheduled")) l.setForeground(WARNING);
                    else l.setForeground(DANGER);
                    return l;
                }
            });
            apptCard.add(new JScrollPane(t), BorderLayout.CENTER);

            // Low stock alerts
            JPanel alertCard = card("⚠️  Low Stock Alerts");
            JPanel alerts = new JPanel();
            alerts.setLayout(new BoxLayout(alerts,BoxLayout.Y_AXIS));
            alerts.setOpaque(false);
            boolean hasAlert = false;
            for(String[] med : MEDICINES){
                if(Integer.parseInt(med[3]) < 20){
                    JLabel l = new JLabel("• "+med[1]+" – Only "+med[3]+" units left");
                    l.setFont(BODY_FONT); l.setForeground(DANGER);
                    l.setBorder(BorderFactory.createEmptyBorder(4,0,4,0));
                    alerts.add(l); hasAlert = true;
                }
            }
            if(!hasAlert){ JLabel ok=new JLabel("✓ All stock levels are fine"); ok.setFont(BODY_FONT); ok.setForeground(SUCCESS); alerts.add(ok); }
            alertCard.add(alerts, BorderLayout.CENTER);
            alertCard.setPreferredSize(new Dimension(260,0));

            JPanel bottom = new JPanel(new BorderLayout(16,0));
            bottom.setOpaque(false);
            bottom.add(apptCard, BorderLayout.CENTER);
            bottom.add(alertCard, BorderLayout.EAST);

            add(statsRow, BorderLayout.NORTH);
            add(bottom, BorderLayout.CENTER);
        }

        JPanel statCard(String label, String val, String icon, Color color) {
            JPanel p = new JPanel(new BorderLayout(10,0));
            p.setBackground(CARD_BG);
            p.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER_CLR,1,true),
                BorderFactory.createEmptyBorder(20,20,20,20)));

            JPanel left = new JPanel(new BorderLayout());
            left.setOpaque(false);
            JLabel num = new JLabel(val); num.setFont(new Font("Segoe UI",Font.BOLD,34)); num.setForeground(color);
            JLabel lbl = new JLabel(label); lbl.setFont(BODY_FONT); lbl.setForeground(TEXT_MID);
            left.add(num,BorderLayout.CENTER); left.add(lbl,BorderLayout.SOUTH);

            JLabel ico = new JLabel(icon,SwingConstants.CENTER);
            ico.setFont(new Font("Segoe UI Emoji",Font.PLAIN,36));
            ico.setPreferredSize(new Dimension(60,60));

            p.add(left,BorderLayout.CENTER); p.add(ico,BorderLayout.EAST);
            return p;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  PATIENT PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class PatientPanel extends JPanel {
        DefaultTableModel model;
        JTable table;
        MainFrame parent;

        PatientPanel(MainFrame parent) {
            this.parent = parent;
            setLayout(new BorderLayout(0,0));
            setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            // ─ Toolbar
            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
            toolbar.setOpaque(false);
            toolbar.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));

            JTextField search = styledField("🔍  Search patient...");
            search.setPreferredSize(new Dimension(240,36));
            JButton addBtn    = primaryBtn("+ Add Patient");
            JButton editBtn   = primaryBtn("✏ Edit");
            JButton delBtn    = dangerBtn("🗑 Delete");
            JButton viewBtn   = successBtn("👁 View Details");

            toolbar.add(sectionLabel("Patient Management"));
            toolbar.add(Box.createHorizontalStrut(20));
            toolbar.add(search); toolbar.add(addBtn);
            toolbar.add(editBtn); toolbar.add(delBtn); toolbar.add(viewBtn);

            // ─ Table
            String[] cols = {"Patient ID","Name","Age","Gender","Contact","Blood","Address","Disease"};
            model = new DefaultTableModel(cols,0);
            refreshTable();
            table = styledTable(cols, model);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(new LineBorder(BORDER_CLR,1,true));
            scroll.getViewport().setBackground(CARD_BG);

            // ─ Actions
            search.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent e){
                    String q = search.getText().toLowerCase();
                    model.setRowCount(0);
                    PATIENTS.stream()
                        .filter(p -> String.join(" ",p).toLowerCase().contains(q))
                        .forEach(p -> model.addRow(p));
                }
            });

            addBtn.addActionListener(e -> showPatientDialog(null));
            editBtn.addActionListener(e -> {
                int r = table.getSelectedRow();
                if(r<0){showMsg(this,"Select a patient to edit.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id = (String)model.getValueAt(r,0);
                String[] pat = PATIENTS.stream().filter(p->p[0].equals(id)).findFirst().orElse(null);
                showPatientDialog(pat);
            });
            delBtn.addActionListener(e -> {
                int r = table.getSelectedRow();
                if(r<0){showMsg(this,"Select a patient to delete.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id = (String)model.getValueAt(r,0);
                int c = JOptionPane.showConfirmDialog(this,"Delete patient "+id+"?","Confirm",JOptionPane.YES_NO_OPTION);
                if(c==JOptionPane.YES_OPTION){ PATIENTS.removeIf(p->p[0].equals(id)); refreshTable(); parent.setStatus("Patient deleted: "+id); }
            });
            viewBtn.addActionListener(e -> {
                int r = table.getSelectedRow();
                if(r<0){showMsg(this,"Select a patient.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String[] p = new String[model.getColumnCount()];
                for(int i=0;i<p.length;i++) p[i]=(String)model.getValueAt(r,i);
                showDetail(p);
            });

            add(toolbar, BorderLayout.NORTH);
            add(scroll,  BorderLayout.CENTER);

            // Count label
            JLabel countLabel = new JLabel("  Total patients: " + PATIENTS.size());
            countLabel.setFont(SMALL_FONT); countLabel.setForeground(TEXT_MID);
            countLabel.setBorder(BorderFactory.createEmptyBorder(8,0,0,0));
            add(countLabel, BorderLayout.SOUTH);
        }

        void refreshTable() {
            model.setRowCount(0);
            PATIENTS.forEach(p -> model.addRow(p));
        }

        void showPatientDialog(String[] existing) {
            JDialog d = new JDialog(); d.setTitle(existing==null?"Add Patient":"Edit Patient");
            d.setSize(480,520); d.setLocationRelativeTo(this); d.setModal(true);
            d.setLayout(new BorderLayout());

            JPanel form = new JPanel(new GridBagLayout());
            form.setBackground(BG); form.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
            GridBagConstraints g = new GridBagConstraints();
            g.insets = new Insets(6,6,6,6); g.anchor = GridBagConstraints.WEST;

            String[] labels = {"Full Name","Age","Gender","Contact No.","Blood Group","Address","Disease/Condition"};
            JComponent[] fields = {
                new JTextField(20), new JTextField(5),
                styledCombo(new String[]{"Male","Female","Other"}),
                new JTextField(15), styledCombo(new String[]{"A+","A-","B+","B-","O+","O-","AB+","AB-"}),
                new JTextField(20), new JTextField(20)
            };

            if(existing!=null){
                ((JTextField)fields[0]).setText(existing[1]);
                ((JTextField)fields[1]).setText(existing[2]);
                ((JComboBox)fields[2]).setSelectedItem(existing[3]);
                ((JTextField)fields[3]).setText(existing[4]);
                ((JComboBox)fields[4]).setSelectedItem(existing[5]);
                ((JTextField)fields[5]).setText(existing[6]);
                ((JTextField)fields[6]).setText(existing[7]);
            }

            for(JComponent c : fields) {
                if(c instanceof JTextField) {
                    ((JTextField)c).setFont(BODY_FONT);
                    ((JTextField)c).setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(BORDER_CLR,1,true), BorderFactory.createEmptyBorder(6,8,6,8)));
                }
            }

            for(int i=0;i<labels.length;i++){
                g.gridx=0; g.gridy=i; g.weightx=0;
                JLabel l=new JLabel(labels[i]+":"); l.setFont(BOLD_FONT); form.add(l,g);
                g.gridx=1; g.weightx=1; g.fill=GridBagConstraints.HORIZONTAL;
                form.add(fields[i],g);
            }

            JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            btnRow.setBackground(BG);
            JButton cancel = new JButton("Cancel"); cancel.setFont(BODY_FONT);
            JButton save = primaryBtn(existing==null?"Add Patient":"Save Changes");
            cancel.addActionListener(e2 -> d.dispose());
            save.addActionListener(e2 -> {
                String name = ((JTextField)fields[0]).getText().trim();
                if(name.isEmpty()){showMsg(d,"Name is required.","Error",JOptionPane.ERROR_MESSAGE);return;}
                String[] np = {
                    existing==null?"P"+String.format("%04d",++patId):existing[0],
                    name, ((JTextField)fields[1]).getText(), (String)((JComboBox)fields[2]).getSelectedItem(),
                    ((JTextField)fields[3]).getText(), (String)((JComboBox)fields[4]).getSelectedItem(),
                    ((JTextField)fields[5]).getText(), ((JTextField)fields[6]).getText()
                };
                if(existing==null){ PATIENTS.add(np); }
                else { int idx=PATIENTS.indexOf(existing); PATIENTS.set(idx,np); }
                refreshTable(); d.dispose();
                parent.setStatus((existing==null?"Added":"Updated")+" patient: "+name);
            });
            btnRow.add(cancel); btnRow.add(save);
            d.add(form, BorderLayout.CENTER); d.add(btnRow, BorderLayout.SOUTH);
            d.setVisible(true);
        }

        void showDetail(String[] p) {
            JDialog d = new JDialog(); d.setTitle("Patient Details – "+p[1]);
            d.setSize(400,360); d.setLocationRelativeTo(this); d.setModal(true);
            d.setLayout(new BorderLayout());
            JPanel panel = new JPanel(new GridLayout(0,2,10,8));
            panel.setBackground(BG); panel.setBorder(BorderFactory.createEmptyBorder(20,24,20,24));
            String[] labels = {"Patient ID","Name","Age","Gender","Contact","Blood Group","Address","Condition"};
            for(int i=0;i<labels.length;i++){
                JLabel k=new JLabel(labels[i]+":"); k.setFont(BOLD_FONT); k.setForeground(PRIMARY);
                JLabel v=new JLabel(p[i]); v.setFont(BODY_FONT);
                panel.add(k); panel.add(v);
            }
            JButton ok = primaryBtn("Close"); ok.addActionListener(e->d.dispose());
            JPanel bp = new JPanel(); bp.setBackground(BG); bp.add(ok);
            d.add(panel,BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH);
            d.setVisible(true);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  DOCTOR PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class DoctorPanel extends JPanel {
        DefaultTableModel model;
        MainFrame parent;

        DoctorPanel(MainFrame parent) {
            this.parent = parent;
            setLayout(new BorderLayout(0,0));
            setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
            toolbar.setOpaque(false); toolbar.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));
            JTextField search = styledField("🔍  Search doctor...");
            search.setPreferredSize(new Dimension(220,36));
            JButton addBtn = primaryBtn("+ Add Doctor");
            JButton delBtn = dangerBtn("🗑 Delete");
            toolbar.add(sectionLabel("Doctor Management"));
            toolbar.add(Box.createHorizontalStrut(20));
            toolbar.add(search); toolbar.add(addBtn); toolbar.add(delBtn);

            String[] cols = {"Doctor ID","Name","Specialization","Contact","Schedule","Consultation Fee"};
            model = new DefaultTableModel(cols,0);
            refreshTable();
            JTable table = styledTable(cols,model);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(new LineBorder(BORDER_CLR,1,true));
            scroll.getViewport().setBackground(CARD_BG);

            search.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent e){
                    String q=search.getText().toLowerCase(); model.setRowCount(0);
                    DOCTORS.stream().filter(d->String.join(" ",d).toLowerCase().contains(q)).forEach(d->model.addRow(d));
                }
            });

            addBtn.addActionListener(e -> {
                JDialog d=new JDialog(); d.setTitle("Add Doctor");
                d.setSize(440,380); d.setLocationRelativeTo(this); d.setModal(true);
                d.setLayout(new BorderLayout());
                JPanel form=new JPanel(new GridBagLayout()); form.setBackground(BG);
                form.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));
                GridBagConstraints g=new GridBagConstraints(); g.insets=new Insets(6,6,6,6); g.anchor=GridBagConstraints.WEST;
                String[] lbls={"Full Name","Specialization","Contact","Schedule (e.g. Mon-Fri)","Consultation Fee (₹)"};
                JTextField[] flds=new JTextField[5];
                for(int i=0;i<lbls.length;i++){
                    flds[i]=new JTextField(20); flds[i].setFont(BODY_FONT);
                    flds[i].setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_CLR,1,true),BorderFactory.createEmptyBorder(6,8,6,8)));
                    g.gridx=0;g.gridy=i;g.weightx=0;JLabel l=new JLabel(lbls[i]+":"); l.setFont(BOLD_FONT); form.add(l,g);
                    g.gridx=1;g.weightx=1;g.fill=GridBagConstraints.HORIZONTAL; form.add(flds[i],g);
                }
                JPanel bp=new JPanel(new FlowLayout(FlowLayout.RIGHT)); bp.setBackground(BG);
                JButton cancel=new JButton("Cancel"); cancel.addActionListener(ev->d.dispose());
                JButton save=primaryBtn("Add Doctor");
                save.addActionListener(ev->{
                    String name=flds[0].getText().trim();
                    if(name.isEmpty()){showMsg(d,"Name required.","Error",JOptionPane.ERROR_MESSAGE);return;}
                    DOCTORS.add(new String[]{"D"+String.format("%03d",++docId),"Dr. "+name,flds[1].getText(),flds[2].getText(),flds[3].getText(),flds[4].getText()});
                    refreshTable(); d.dispose(); parent.setStatus("Doctor added: "+name);
                });
                bp.add(cancel); bp.add(save);
                d.add(form,BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH); d.setVisible(true);
            });

            delBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select a doctor.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                int c2=JOptionPane.showConfirmDialog(this,"Delete "+id+"?","Confirm",JOptionPane.YES_NO_OPTION);
                if(c2==JOptionPane.YES_OPTION){DOCTORS.removeIf(dc->dc[0].equals(id)); refreshTable(); parent.setStatus("Doctor deleted: "+id);}
            });

            add(toolbar,BorderLayout.NORTH); add(scroll,BorderLayout.CENTER);
        }
        void refreshTable(){ model.setRowCount(0); DOCTORS.forEach(d->model.addRow(d)); }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  APPOINTMENT PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class AppointmentPanel extends JPanel {
        DefaultTableModel model;
        MainFrame parent;

        AppointmentPanel(MainFrame parent) {
            this.parent = parent;
            setLayout(new BorderLayout(0,0)); setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
            toolbar.setOpaque(false); toolbar.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));
            JButton addBtn    = primaryBtn("+ Book Appointment");
            JButton cancelBtn = dangerBtn("✗ Cancel Appt");
            JButton doneBtn   = successBtn("✓ Mark Complete");
            toolbar.add(sectionLabel("Appointment Scheduling"));
            toolbar.add(Box.createHorizontalStrut(16));
            toolbar.add(addBtn); toolbar.add(cancelBtn); toolbar.add(doneBtn);

            String[] cols = {"Appt ID","Patient ID","Patient Name","Doctor","Date","Time","Status"};
            model = new DefaultTableModel(cols,0);
            refreshTable();
            JTable table = styledTable(cols,model);
            // Color status
            table.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer(){
                public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                    JLabel l=(JLabel)super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                    l.setHorizontalAlignment(CENTER); l.setFont(BOLD_FONT);
                    switch(val.toString()){
                        case "Completed": l.setForeground(SUCCESS); break;
                        case "Cancelled": l.setForeground(DANGER); break;
                        default: l.setForeground(WARNING);
                    }
                    return l;
                }
            });
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(new LineBorder(BORDER_CLR,1,true));
            scroll.getViewport().setBackground(CARD_BG);

            addBtn.addActionListener(e -> {
                JDialog d = new JDialog(); d.setTitle("Book Appointment");
                d.setSize(420,360); d.setLocationRelativeTo(this); d.setModal(true);
                d.setLayout(new BorderLayout());
                JPanel form = new JPanel(new GridBagLayout()); form.setBackground(BG);
                form.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));
                GridBagConstraints g = new GridBagConstraints(); g.insets=new Insets(7,6,7,6); g.anchor=GridBagConstraints.WEST;

                String[] patNames = PATIENTS.stream().map(p->p[0]+" – "+p[1]).toArray(String[]::new);
                String[] docNames = DOCTORS.stream().map(dc->dc[1]).toArray(String[]::new);
                JComboBox<String> patBox = styledCombo(patNames.length>0?patNames:new String[]{"No Patients"});
                JComboBox<String> docBox = styledCombo(docNames.length>0?docNames:new String[]{"No Doctors"});
                JTextField dateF = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()),12);
                JTextField timeF = new JTextField("10:00",8);
                for(JTextField f:new JTextField[]{dateF,timeF}){
                    f.setFont(BODY_FONT); f.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_CLR,1,true),BorderFactory.createEmptyBorder(6,8,6,8)));
                }

                String[][] rows2 = {{"Patient",null},{"Doctor",null},{"Date (YYYY-MM-DD)",null},{"Time (HH:MM)",null}};
                JComponent[] comps = {patBox,docBox,dateF,timeF};
                for(int i=0;i<rows2.length;i++){
                    g.gridx=0;g.gridy=i;g.weightx=0;JLabel l=new JLabel(rows2[i][0]+":"); l.setFont(BOLD_FONT); form.add(l,g);
                    g.gridx=1;g.weightx=1;g.fill=GridBagConstraints.HORIZONTAL; form.add(comps[i],g);
                }

                JPanel bp=new JPanel(new FlowLayout(FlowLayout.RIGHT)); bp.setBackground(BG);
                JButton cancel=new JButton("Cancel"); cancel.addActionListener(ev->d.dispose());
                JButton book=primaryBtn("Book");
                book.addActionListener(ev->{
                    if(patNames.length==0||docNames.length==0){showMsg(d,"Add patients and doctors first.","Error",JOptionPane.ERROR_MESSAGE);return;}
                    String patSel=(String)patBox.getSelectedItem();
                    String patId2=patSel.split(" – ")[0], patName2=patSel.split(" – ")[1];
                    String docName2=(String)docBox.getSelectedItem();
                    APPOINTMENTS.add(new String[]{"A"+String.format("%04d",++apptId),patId2,patName2,docName2,dateF.getText(),timeF.getText(),"Scheduled"});
                    refreshTable(); d.dispose(); parent.setStatus("Appointment booked for "+patName2);
                });
                bp.add(cancel); bp.add(book);
                d.add(form,BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH); d.setVisible(true);
            });

            cancelBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select an appointment.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                APPOINTMENTS.stream().filter(a->a[0].equals(id)).findFirst().ifPresent(a->a[6]="Cancelled");
                refreshTable(); parent.setStatus("Appointment cancelled: "+id);
            });
            doneBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select an appointment.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                APPOINTMENTS.stream().filter(a->a[0].equals(id)).findFirst().ifPresent(a->a[6]="Completed");
                refreshTable(); parent.setStatus("Marked complete: "+id);
            });

            add(toolbar,BorderLayout.NORTH); add(scroll,BorderLayout.CENTER);
        }
        void refreshTable(){ model.setRowCount(0); APPOINTMENTS.forEach(a->model.addRow(a)); }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  BILLING PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class BillingPanel extends JPanel {
        DefaultTableModel model;
        MainFrame parent;

        BillingPanel(MainFrame parent) {
            this.parent = parent;
            setLayout(new BorderLayout(0,16)); setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
            toolbar.setOpaque(false); toolbar.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));
            JButton genBtn  = primaryBtn("+ Generate Bill");
            JButton payBtn  = successBtn("✓ Mark Paid");
            JButton printBtn= primaryBtn("🖨 Print/View");
            toolbar.add(sectionLabel("Billing & Payments"));
            toolbar.add(Box.createHorizontalStrut(16));
            toolbar.add(genBtn); toolbar.add(payBtn); toolbar.add(printBtn);

            String[] cols = {"Bill ID","Patient Name","Appt ID","Amount (₹)","Payment Mode","Status","Date"};
            model = new DefaultTableModel(cols,0);
            refreshTable();
            JTable table = styledTable(cols,model);
            table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer(){
                public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                    JLabel l=(JLabel)super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                    l.setHorizontalAlignment(CENTER); l.setFont(BOLD_FONT);
                    l.setForeground(val.toString().equals("Paid")?SUCCESS:DANGER);
                    return l;
                }
            });
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(new LineBorder(BORDER_CLR,1,true));
            scroll.getViewport().setBackground(CARD_BG);

            // Summary card
            JPanel summary = new JPanel(new GridLayout(1,3,14,0));
            summary.setOpaque(false);
            double totalRev = BILLS.stream().filter(b->b[5].equals("Paid")).mapToDouble(b->Double.parseDouble(b[3])).sum();
            long pendCnt = BILLS.stream().filter(b->b[5].equals("Pending")).count();
            summary.add(summaryCard("Total Revenue", "₹ "+String.format("%.0f",totalRev), SUCCESS));
            summary.add(summaryCard("Pending Bills", String.valueOf(pendCnt), DANGER));
            summary.add(summaryCard("Total Bills",   String.valueOf(BILLS.size()), PRIMARY));

            genBtn.addActionListener(e -> {
                JDialog d=new JDialog(); d.setTitle("Generate Bill");
                d.setSize(420,360); d.setLocationRelativeTo(this); d.setModal(true);
                d.setLayout(new BorderLayout());
                JPanel form=new JPanel(new GridBagLayout()); form.setBackground(BG);
                form.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));
                GridBagConstraints g=new GridBagConstraints(); g.insets=new Insets(8,6,8,6); g.anchor=GridBagConstraints.WEST;

                String[] appts=APPOINTMENTS.stream().map(a->a[0]+" – "+a[2]).toArray(String[]::new);
                JComboBox<String> apptBox=styledCombo(appts.length>0?appts:new String[]{"No Appointments"});
                JTextField amtF=new JTextField("1000",10);
                JComboBox<String> modeBox=styledCombo(new String[]{"Cash","UPI","Card","Insurance"});
                for(JTextField f:new JTextField[]{amtF}){
                    f.setFont(BODY_FONT); f.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_CLR,1,true),BorderFactory.createEmptyBorder(6,8,6,8)));
                }
                Object[][] rows2={{"Appointment",apptBox},{"Amount (₹)",amtF},{"Payment Mode",modeBox}};
                for(int i=0;i<rows2.length;i++){
                    g.gridx=0;g.gridy=i;g.weightx=0;JLabel l=new JLabel(rows2[i][0]+":"); l.setFont(BOLD_FONT); form.add(l,g);
                    g.gridx=1;g.weightx=1;g.fill=GridBagConstraints.HORIZONTAL; form.add((JComponent)rows2[i][1],g);
                }
                JPanel bp=new JPanel(new FlowLayout(FlowLayout.RIGHT)); bp.setBackground(BG);
                JButton cancel=new JButton("Cancel"); cancel.addActionListener(ev->d.dispose());
                JButton gen=primaryBtn("Generate");
                gen.addActionListener(ev->{
                    if(appts.length==0){showMsg(d,"No appointments found.","Error",JOptionPane.ERROR_MESSAGE);return;}
                    String sel=(String)apptBox.getSelectedItem();
                    String apptId2=sel.split(" – ")[0], patName2=sel.split(" – ")[1];
                    String date=new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                    BILLS.add(new String[]{"B"+String.format("%04d",++billId),patName2,apptId2,amtF.getText(),(String)modeBox.getSelectedItem(),"Pending",date});
                    refreshTable(); d.dispose(); parent.setStatus("Bill generated for "+patName2);
                });
                bp.add(cancel); bp.add(gen);
                d.add(form,BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH); d.setVisible(true);
            });

            payBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select a bill.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                BILLS.stream().filter(b->b[0].equals(id)).findFirst().ifPresent(b->b[5]="Paid");
                refreshTable(); parent.setStatus("Bill marked paid: "+id);
            });

            printBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select a bill.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String[] b=new String[model.getColumnCount()];
                for(int i=0;i<b.length;i++) b[i]=(String)model.getValueAt(r,i);
                showInvoice(b);
            });

            add(summary,  BorderLayout.NORTH);
            add(toolbar,  BorderLayout.CENTER);
            JPanel ctr = new JPanel(new BorderLayout());
            ctr.setOpaque(false);
            ctr.add(toolbar,BorderLayout.NORTH); ctr.add(scroll,BorderLayout.CENTER);
            add(summary,BorderLayout.NORTH); add(ctr,BorderLayout.CENTER);
        }

        JPanel summaryCard(String label, String val, Color color) {
            JPanel p=new JPanel(new BorderLayout()); p.setBackground(CARD_BG);
            p.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_CLR,1,true),BorderFactory.createEmptyBorder(14,18,14,18)));
            JLabel v=new JLabel(val); v.setFont(new Font("Segoe UI",Font.BOLD,28)); v.setForeground(color);
            JLabel l=new JLabel(label); l.setFont(BODY_FONT); l.setForeground(TEXT_MID);
            p.add(v,BorderLayout.CENTER); p.add(l,BorderLayout.SOUTH);
            return p;
        }

        void refreshTable(){ model.setRowCount(0); BILLS.forEach(b->model.addRow(b)); }

        void showInvoice(String[] b) {
            JDialog d=new JDialog(); d.setTitle("Invoice – "+b[0]);
            d.setSize(420,460); d.setLocationRelativeTo(this); d.setModal(true);
            d.setLayout(new BorderLayout());
            JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
            p.setBackground(Color.WHITE); p.setBorder(BorderFactory.createEmptyBorder(24,30,24,30));

            // Header
            JLabel hdr=new JLabel("🏥  HOSPITAL MANAGEMENT SYSTEM"); hdr.setFont(new Font("Segoe UI",Font.BOLD,15)); hdr.setForeground(PRIMARY); hdr.setAlignmentX(CENTER_ALIGNMENT);
            JLabel sub=new JLabel("Tax Invoice"); sub.setFont(new Font("Segoe UI",Font.BOLD,13)); sub.setForeground(TEXT_MID); sub.setAlignmentX(CENTER_ALIGNMENT);
            p.add(hdr); p.add(Box.createVerticalStrut(4)); p.add(sub);
            p.add(Box.createVerticalStrut(16));

            // Divider
            JSeparator sep=new JSeparator(); sep.setForeground(PRIMARY); sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,2));
            p.add(sep); p.add(Box.createVerticalStrut(14));

            String[][] rows={{"Bill ID",b[0]},{"Patient Name",b[1]},{"Appointment ID",b[2]},{"Date",b[6]},{"Payment Mode",b[4]},{"",""},{"Amount",b[3]+" (₹)"},{"Status",b[5]}};
            for(String[] row:rows){
                if(row[0].isEmpty()){p.add(new JSeparator());p.add(Box.createVerticalStrut(8));continue;}
                JPanel row2=new JPanel(new BorderLayout()); row2.setOpaque(false); row2.setMaximumSize(new Dimension(Integer.MAX_VALUE,28));
                JLabel k=new JLabel(row[0]); k.setFont(BOLD_FONT); k.setForeground(TEXT_MID);
                JLabel v=new JLabel(row[1]);
                if(row[0].equals("Amount")) v.setFont(new Font("Segoe UI",Font.BOLD,18));
                else v.setFont(BODY_FONT);
                if(row[0].equals("Status")) v.setForeground(b[5].equals("Paid")?SUCCESS:DANGER);
                row2.add(k,BorderLayout.WEST); row2.add(v,BorderLayout.EAST);
                p.add(row2); p.add(Box.createVerticalStrut(6));
            }
            p.add(Box.createVerticalStrut(20));
            JLabel footer=new JLabel("Thank you for choosing our hospital services."); footer.setFont(SMALL_FONT); footer.setForeground(TEXT_MID); footer.setAlignmentX(CENTER_ALIGNMENT);
            p.add(footer);

            JPanel bp=new JPanel(); bp.setBackground(Color.WHITE);
            JButton close=primaryBtn("Close"); close.addActionListener(ev->d.dispose());
            bp.add(close);
            d.add(new JScrollPane(p),BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH);
            d.setVisible(true);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    //  PHARMACY PANEL
    // ═════════════════════════════════════════════════════════════════════════
    static class PharmacyPanel extends JPanel {
        DefaultTableModel model;
        MainFrame parent;

        PharmacyPanel(MainFrame parent) {
            this.parent = parent;
            setLayout(new BorderLayout(0,0)); setBackground(BG);
            setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            JPanel toolbar=new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
            toolbar.setOpaque(false); toolbar.setBorder(BorderFactory.createEmptyBorder(0,0,14,0));
            JTextField search=styledField("🔍  Search medicine..."); search.setPreferredSize(new Dimension(220,36));
            JButton addBtn=primaryBtn("+ Add Medicine");
            JButton updateBtn=primaryBtn("📦 Update Stock");
            JButton delBtn=dangerBtn("🗑 Delete");
            toolbar.add(sectionLabel("Pharmacy Inventory"));
            toolbar.add(Box.createHorizontalStrut(16));
            toolbar.add(search); toolbar.add(addBtn); toolbar.add(updateBtn); toolbar.add(delBtn);

            String[] cols={"Med ID","Medicine Name","Category","Stock (Units)","Price (₹)","Expiry Date"};
            model=new DefaultTableModel(cols,0);
            refreshTable();
            JTable table=styledTable(cols,model);

            // Highlight low stock
            table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer(){
                public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                    JLabel l=(JLabel)super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                    l.setHorizontalAlignment(CENTER); l.setFont(BOLD_FONT);
                    try{ l.setForeground(Integer.parseInt(val.toString())<20?DANGER:SUCCESS); }catch(Exception ignored){}
                    return l;
                }
            });
            JScrollPane scroll=new JScrollPane(table);
            scroll.setBorder(new LineBorder(BORDER_CLR,1,true));
            scroll.getViewport().setBackground(CARD_BG);

            search.addKeyListener(new KeyAdapter(){
                public void keyReleased(KeyEvent e){
                    String q=search.getText().toLowerCase(); model.setRowCount(0);
                    MEDICINES.stream().filter(m->String.join(" ",m).toLowerCase().contains(q)).forEach(m->model.addRow(m));
                }
            });

            addBtn.addActionListener(e->{
                JDialog d=new JDialog(); d.setTitle("Add Medicine");
                d.setSize(420,360); d.setLocationRelativeTo(this); d.setModal(true);
                d.setLayout(new BorderLayout());
                JPanel form=new JPanel(new GridBagLayout()); form.setBackground(BG);
                form.setBorder(BorderFactory.createEmptyBorder(16,20,16,20));
                GridBagConstraints g=new GridBagConstraints(); g.insets=new Insets(7,6,7,6); g.anchor=GridBagConstraints.WEST;
                String[] lbls={"Medicine Name","Category","Stock Quantity","Price per Unit (₹)","Expiry Date (YYYY-MM-DD)"};
                JTextField[] flds=new JTextField[5];
                for(int i=0;i<lbls.length;i++){
                    flds[i]=new JTextField(20); flds[i].setFont(BODY_FONT);
                    flds[i].setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_CLR,1,true),BorderFactory.createEmptyBorder(6,8,6,8)));
                    g.gridx=0;g.gridy=i;g.weightx=0;JLabel l=new JLabel(lbls[i]+":"); l.setFont(BOLD_FONT); form.add(l,g);
                    g.gridx=1;g.weightx=1;g.fill=GridBagConstraints.HORIZONTAL; form.add(flds[i],g);
                }
                JPanel bp=new JPanel(new FlowLayout(FlowLayout.RIGHT)); bp.setBackground(BG);
                JButton cancel=new JButton("Cancel"); cancel.addActionListener(ev->d.dispose());
                JButton add2=primaryBtn("Add Medicine");
                add2.addActionListener(ev->{
                    String name=flds[0].getText().trim();
                    if(name.isEmpty()){showMsg(d,"Name required.","Error",JOptionPane.ERROR_MESSAGE);return;}
                    MEDICINES.add(new String[]{"M"+String.format("%04d",++medId),name,flds[1].getText(),flds[2].getText(),flds[3].getText(),flds[4].getText()});
                    refreshTable(); d.dispose(); parent.setStatus("Medicine added: "+name);
                });
                bp.add(cancel); bp.add(add2);
                d.add(form,BorderLayout.CENTER); d.add(bp,BorderLayout.SOUTH); d.setVisible(true);
            });

            updateBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select a medicine.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                String cur=(String)model.getValueAt(r,3);
                String input=JOptionPane.showInputDialog(this,"Current Stock: "+cur+"\nEnter new stock quantity:","Update Stock",JOptionPane.QUESTION_MESSAGE);
                if(input!=null&&!input.isBlank()){
                    MEDICINES.stream().filter(m->m[0].equals(id)).findFirst().ifPresent(m->m[3]=input.trim());
                    refreshTable(); parent.setStatus("Stock updated for "+id);
                }
            });

            delBtn.addActionListener(e->{
                int r=table.getSelectedRow();
                if(r<0){showMsg(this,"Select a medicine.","Info",JOptionPane.INFORMATION_MESSAGE);return;}
                String id=(String)model.getValueAt(r,0);
                int c=JOptionPane.showConfirmDialog(this,"Delete "+id+"?","Confirm",JOptionPane.YES_NO_OPTION);
                if(c==JOptionPane.YES_OPTION){MEDICINES.removeIf(m->m[0].equals(id)); refreshTable(); parent.setStatus("Medicine deleted: "+id);}
            });

            // Low stock warning bar
            long lowCount=MEDICINES.stream().filter(m->Integer.parseInt(m[3])<20).count();
            JLabel warning=new JLabel(lowCount>0?"  ⚠️  "+lowCount+" medicine(s) have low stock (< 20 units). Please restock.":"  ✓  All stock levels are adequate.");
            warning.setFont(BOLD_FONT); warning.setOpaque(true);
            warning.setBackground(lowCount>0?new Color(255,243,205):new Color(212,237,218));
            warning.setForeground(lowCount>0?new Color(133,77,14):new Color(21,87,36));
            warning.setBorder(BorderFactory.createEmptyBorder(8,14,8,14));

            JPanel mainContent=new JPanel(new BorderLayout(0,12)); mainContent.setOpaque(false);
            mainContent.add(toolbar,BorderLayout.NORTH); mainContent.add(scroll,BorderLayout.CENTER);

            add(warning,BorderLayout.NORTH); add(mainContent,BorderLayout.CENTER);
        }
        void refreshTable(){ model.setRowCount(0); MEDICINES.forEach(m->model.addRow(m)); }
    }
}
